const reveals=document.querySelectorAll('.reveal');
function reveal(){reveals.forEach(e=>{if(e.getBoundingClientRect().top<window.innerHeight-100)e.classList.add('active')})}
window.addEventListener('scroll',reveal);reveal();
