const map=L.map('map').setView([25.033,121.5654],15);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'OSM'}).addTo(map);

let favorites=[];

navigator.geolocation.getCurrentPosition(async(p)=>{
  const lat=p.coords.latitude,lng=p.coords.longitude;
  map.setView([lat,lng],16);
  L.marker([lat,lng]).addTo(map);
  load(lat,lng);
});

async function load(lat,lng){
const res=await fetch("https://overpass-api.de/api/interpreter",{method:"POST",body:`[out:json];node["amenity"~"restaurant|cafe"](around:1000,${lat},${lng});out;`});
const data=await res.json();
const list=document.getElementById('list');
list.innerHTML="<h3>餐廳</h3>";

data.elements.forEach(e=>{
if(!e.lat)return;
const p={name:e.tags?.name||"未知",lat:e.lat,lng:e.lon};
const m=L.marker([p.lat,p.lng]).addTo(map);

const d=document.createElement('div');
d.className='card';
d.innerHTML=p.name;
d.onclick=()=>map.setView([p.lat,p.lng],18);
list.appendChild(d);
});
}
